// ---------- Mobile nav toggle ----------
document.addEventListener('DOMContentLoaded', () => {
  const toggle = document.querySelector('.nav-toggle');
  const links = document.querySelector('.nav-links');
  if (toggle && links) {
    toggle.addEventListener('click', () => {
      const isOpen = links.classList.toggle('open');
      toggle.setAttribute('aria-expanded', isOpen ? 'true' : 'false');
    });
    links.querySelectorAll('a').forEach((a) => {
      a.addEventListener('click', () => links.classList.remove('open'));
    });
  }

  // ---------- Copy email to clipboard ----------
  document.querySelectorAll('[data-copy]').forEach((btn) => {
    btn.addEventListener('click', async () => {
      const value = btn.getAttribute('data-copy');
      const original = btn.textContent;
      try {
        await navigator.clipboard.writeText(value);
        btn.textContent = 'Copied';
      } catch (e) {
        btn.textContent = 'Copy failed — select manually';
      }
      setTimeout(() => { btn.textContent = original; }, 1800);
    });
  });

  // ---------- Terminal typing animation (home hero) ----------
  const terminalBody = document.getElementById('terminal-body');
  if (terminalBody) {
    const lines = JSON.parse(terminalBody.getAttribute('data-lines'));
    const prefersReduced = window.matchMedia('(prefers-reduced-motion: reduce)').matches;

    if (prefersReduced) {
      terminalBody.innerHTML = lines.map(renderLine).join('');
    } else {
      typeLines(terminalBody, lines);
    }
  }
});

function renderLine(line) {
  return `<div class="terminal-line">${line.html}</div>`;
}

function typeLines(container, lines, lineIndex = 0) {
  if (lineIndex >= lines.length) {
    const cursor = document.createElement('span');
    cursor.className = 'terminal-cursor';
    container.appendChild(cursor);
    return;
  }

  const line = lines[lineIndex];
  const el = document.createElement('div');
  el.className = 'terminal-line';
  container.appendChild(el);

  if (line.instant) {
    el.innerHTML = line.html;
    window.setTimeout(() => typeLines(container, lines, lineIndex + 1), line.pause || 200);
    return;
  }

  const text = line.text;
  let charIndex = 0;
  const speed = line.speed || 18;

  function typeChar() {
    charIndex++;
    el.textContent = text.slice(0, charIndex);
    if (charIndex < text.length) {
      window.setTimeout(typeChar, speed);
    } else {
      el.innerHTML = colorize(text);
      window.setTimeout(() => typeLines(container, lines, lineIndex + 1), line.pause || 260);
    }
  }
  typeChar();
}

function colorize(text) {
  if (text.startsWith('$ ')) {
    return `<span class="prompt-sym">$</span> ${escapeHtml(text.slice(2))}`;
  }
  if (text.startsWith('[PASS]')) {
    return `<span class="pass">[PASS]</span> ${escapeHtml(text.slice(6))}`;
  }
  if (text.startsWith('# ')) {
    return `<span class="comment">${escapeHtml(text)}</span>`;
  }
  return `<span class="result">${escapeHtml(text)}</span>`;
}

function escapeHtml(str) {
  const div = document.createElement('div');
  div.textContent = str;
  return div.innerHTML;
}
